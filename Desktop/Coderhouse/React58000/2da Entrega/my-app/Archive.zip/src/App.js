
// Importing app.css is css file to add styling
import "./App.css";
import NavBar from './components/navbar/NavBar'
import ItemListContainer from './components/itemlistcontainer/itemlistcontainer'
import ItemDetailContainer from './components/ItemDetailContainer/ItemDetailContainer'

function App() {
	return(
		<div className="App">
			<NavBar />
			<ItemListContainer greeting={'Bienvenidos'}/>
			<ItemDetailContainer />
		</div>
	);
}

export default App;